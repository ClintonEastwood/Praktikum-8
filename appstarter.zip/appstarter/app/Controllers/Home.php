<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return view('home');
    }

    public function device(){
        
        $device = [
            'title' => 'data',
            'data' => [
                [
                    'id' => '1',
                    'device_name' => 'Arduion',
                    'device_brand' => 'Geuino',
                    'device_quantity' => '19',
                    'device_status' => '1'
                ],
                [
                    'id' => '2',
                    'device_name' => 'Komputer',
                    'device_brand' => 'Samsung',
                    'device_quantity' => '20',
                    'device_status' => '1'
                ],
                [
                    'id' => '3',
                    'device_name' => 'Projector',
                    'device_brand' => 'Canon',
                    'device_quantity' => '2',
                    'device_status' => '0'
                ]
            ]
        ];

        return view('device', $device);
    }
}
